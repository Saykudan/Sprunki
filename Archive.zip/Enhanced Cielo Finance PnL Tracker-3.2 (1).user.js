// ==UserScript==
// @name         Enhanced Cielo Finance PnL Tracker
// @namespace    http://tampermonkey.net/
// @version      3.2
// @description  Modern UI + robust logic + combined PnL/ROI display
// @author       You
// @match        *://*.cielo.finance/*
// @match        https://app.cielo.finance/*
// @match        http://app.cielo.finance/*
// @grant        GM_addStyle
// @grant        GM_setValue
// @grant        GM_getValue
// ==/UserScript==

(function() {
    'use strict';

    console.log('Enhanced Cielo Tracker: Starting initialization...');

    // -------------- 1) Modern DexScreener-like UI Styles --------------
    GM_addStyle(`
        .cielo-tracker {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            background: rgba(17, 25, 40, 0.95);
            backdrop-filter: blur(8px);
            border-radius: 16px;
            border: 1px solid rgba(255, 255, 255, 0.1);
            width: 520px;
            font-family: 'Inter', system-ui, -apple-system, sans-serif;
            max-height: 90vh;
            overflow: hidden;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            color: #E5E7EB;
        }

        .cielo-tracker * {
            box-sizing: border-box;
        }

        .cielo-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 16px 20px;
            background: rgba(255, 255, 255, 0.05);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .header-title {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 16px;
            font-weight: 600;
            color: #fff;
        }

        .header-title svg {
            width: 20px;
            height: 20px;
            stroke: #10B981;
        }

        .minimize-button {
            cursor: pointer;
            padding: 8px;
            border-radius: 8px;
            background: rgba(255, 255, 255, 0.05);
            border: none;
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s ease;
        }

        .minimize-button:hover {
            background: rgba(255, 255, 255, 0.1);
        }

        .tracker-content {
            padding: 20px;
            overflow-y: auto;
            max-height: calc(90vh - 60px);
        }

        .input-section {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 12px;
            padding: 16px;
            margin-bottom: 20px;
        }

        .wallet-textarea {
            width: 100%;
            height: 100px;
            background: rgba(17, 25, 40, 0.7);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            padding: 12px;
            color: #fff;
            font-family: 'Roboto Mono', monospace;
            font-size: 14px;
            resize: vertical;
            margin-bottom: 12px;
        }

        .wallet-textarea:focus {
            outline: none;
            border-color: #10B981;
        }

        .action-button {
            width: 100%;
            padding: 12px;
            background: linear-gradient(135deg, #10B981, #059669);
            color: white;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: all 0.2s ease;
        }

        .action-button:hover:not(:disabled) {
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
        }

        .action-button:disabled {
            background: rgba(255, 255, 255, 0.1);
            cursor: not-allowed;
        }

        .action-button svg {
            width: 18px;
            height: 18px;
        }

        .results-section {
            display: grid;
            gap: 16px;
        }

        .wallet-card {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 12px;
            padding: 16px;
            border: 1px solid rgba(255, 255, 255, 0.1);
            transition: transform 0.2s ease;
        }

        .wallet-card:hover {
            transform: translateY(-2px);
        }

        .wallet-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 16px;
            padding-bottom: 12px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .wallet-address-container {
            display: flex;
            flex-direction: column;
            gap: 6px;
        }

        .wallet-address {
            font-family: 'Roboto Mono', monospace;
            font-size: 14px;
            color: #fff;
            background: rgba(255, 255, 255, 0.05);
            padding: 6px 12px;
            border-radius: 6px;
            max-width: 280px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .sol-info {
            font-size: 14px;
            color: #10B981;
            font-weight: 500;
        }

        .wallet-actions {
            display: flex;
            gap: 8px;
        }

        .wallet-action-btn {
            background: transparent;
            border: 1px solid rgba(255, 255, 255, 0.2);
            color: #fff;
            padding: 6px;
            border-radius: 6px;
            cursor: pointer;
            display: flex;
            align-items: center;
            transition: all 0.2s ease;
        }

        .wallet-action-btn:hover {
            background: rgba(255, 255, 255, 0.1);
            border-color: rgba(255, 255, 255, 0.3);
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 12px;
        }

        .stat-card {
            background: rgba(17, 25, 40, 0.7);
            padding: 12px;
            border-radius: 8px;
            display: flex;
            flex-direction: column;
            gap: 4px;
        }

        .stat-card[style*="grid-column: span 2"] {
            grid-column: span 2;
        }

        .stat-card[style*="grid-column: span 2"] .stat-value {
            font-size: 18px;
            line-height: 1.4;
        }

        .stat-label {
            font-size: 12px;
            color: rgba(255, 255, 255, 0.6);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .stat-value {
            font-size: 16px;
            font-weight: 600;
            color: #fff;
        }

        .stat-value.positive {
            color: #10B981;
        }

        .stat-value.negative {
            color: #EF4444;
        }

        .winrate-badge {
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }

        .winrate-badge.high {
            background: rgba(16, 185, 129, 0.1);
            color: #10B981;
        }

        .winrate-badge.medium {
            background: rgba(245, 158, 11, 0.1);
            color: #F59E0B;
        }

        .winrate-badge.low {
            background: rgba(239, 68, 68, 0.1);
            color: #EF4444;
        }

        .timeframe-tabs {
            display: flex;
            gap: 8px;
            margin-bottom: 16px;
            background: rgba(255, 255, 255, 0.05);
            padding: 8px;
            border-radius: 8px;
        }

        .timeframe-tab {
            padding: 8px 16px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            color: rgba(255, 255, 255, 0.6);
            transition: all 0.2s ease;
            flex: 1;
            text-align: center;
        }

        .timeframe-tab:hover {
            background: rgba(255, 255, 255, 0.1);
        }

        .timeframe-tab.active {
            background: rgba(16, 185, 129, 0.1);
            color: #10B981;
        }

        /* Loading States */
        .loading-shimmer {
            background: linear-gradient(
                90deg,
                rgba(255, 255, 255, 0.03) 0%,
                rgba(255, 255, 255, 0.08) 50%,
                rgba(255, 255, 255, 0.03) 100%
            );
            background-size: 200% 100%;
            animation: shimmer 1.5s infinite;
        }

        @keyframes shimmer {
            0% { background-position: -200% 0; }
            100% { background-position: 200% 0; }
        }

        /* Minimized State */
        .cielo-tracker.minimized {
            width: 48px;
            height: 48px;
            overflow: hidden;
            padding: 0;
            border-radius: 24px;
            cursor: pointer;
        }

        .cielo-tracker.minimized .tracker-content {
            display: none;
        }

        .bubble-icon {
            width: 48px;
            height: 48px;
            border-radius: 50%;
            background: linear-gradient(135deg, #10B981, #059669);
            display: none;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 24px;
        }

        .cielo-tracker.minimized .bubble-icon {
            display: flex;
        }

        /* Tooltip */
        [data-tooltip] {
            position: relative;
        }

        [data-tooltip]:after {
            content: attr(data-tooltip);
            position: absolute;
            bottom: 100%;
            left: 50%;
            transform: translateX(-50%);
            padding: 4px 8px;
            background: rgba(0, 0, 0, 0.8);
            color: white;
            font-size: 12px;
            border-radius: 4px;
            white-space: nowrap;
            opacity: 0;
            visibility: hidden;
            transition: all 0.2s ease;
            pointer-events: none;
            margin-bottom: 4px;
        }

        [data-tooltip]:hover:after {
            opacity: 1;
            visibility: visible;
        }

        /* Toast Notifications */
        .toast-container {
            position: fixed;
            bottom: 20px;
            right: 20px;
            z-index: 10000;
        }

        .toast {
            background: rgba(17, 25, 40, 0.95);
            backdrop-filter: blur(8px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            padding: 12px 16px;
            margin-top: 8px;
            display: flex;
            align-items: center;
            gap: 8px;
            color: #fff;
            font-size: 14px;
            transform: translateX(120%);
            transition: transform 0.3s ease;
        }

        .toast.show {
            transform: translateX(0);
        }

        .toast.success {
            border-left: 4px solid #10B981;
        }

        .toast.error {
            border-left: 4px solid #EF4444;
        }

            .performance-group {
        margin-bottom: 32px;
    }

    .group-title {
        font-size: 18px;
        font-weight: 600;
        color: #fff;
        margin-bottom: 16px;
        padding-bottom: 8px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }

    .group-wallets {
        display: grid;
        gap: 16px;
    }

    .timeframe-tabs {
        margin-bottom: 16px;
    }

    .wallet-card .timeframe-tabs {
        background: rgba(255, 255, 255, 0.03);
        border-radius: 8px;
        padding: 6px;
        margin-bottom: 12px;
    }
        .group-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        cursor: pointer;
        padding: 12px 16px;
        background: rgba(255, 255, 255, 0.05);
        border-radius: 8px;
        margin-bottom: 16px;
    }

    .group-header:hover {
        background: rgba(255, 255, 255, 0.08);
    }

    .group-title-container {
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .group-title {
        margin: 0;
        font-size: 16px;
        font-weight: 600;
        color: #fff;
    }

    .wallet-count {
        background: rgba(16, 185, 129, 0.1);
        color: #10B981;
        padding: 2px 8px;
        border-radius: 12px;
        font-size: 12px;
        font-weight: 500;
    }

    .group-actions {
        display: flex;
        align-items: center;
        gap: 12px;
    }

    .copy-wallets-btn {
        background: transparent;
        border: 1px solid rgba(255, 255, 255, 0.2);
        color: #fff;
        padding: 6px 12px;
        border-radius: 6px;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 6px;
        font-size: 12px;
        transition: all 0.2s ease;
    }

    .copy-wallets-btn:hover {
        background: rgba(255, 255, 255, 0.1);
        border-color: rgba(255, 255, 255, 0.3);
    }

    .toggle-icon {
        transition: transform 0.2s ease;
    }

    .group-header.collapsed .toggle-icon {
        transform: rotate(-90deg);
    }

    .group-wallets {
        transition: all 0.3s ease;
        max-height: 2000px;
        opacity: 1;
        overflow: hidden;
    }

    .group-wallets.collapsed {
        max-height: 0;
        opacity: 0;
        margin: 0;
    }
    `);

    // -------------- 2) Local Storage + Utility Functions --------------
    const HISTORY_KEY = 'enhanced_cielo_scan_history';
    let scanHistory = GM_getValue(HISTORY_KEY, {});

    const utils = {
        formatCurrency(value) {
            if (value === 'N/A') return 'N/A';
            const numeric = parseFloat((value + '').replace(/[^0-9.-]/g, '')) || 0;
            if (!numeric) return '$0';
            return new Intl.NumberFormat('en-US', {
                style: 'currency',
                currency: 'USD',
                notation: 'compact',
                compactDisplay: 'short'
            }).format(numeric);
        },
        truncateAddress(address, start = 6, end = 4) {
            if (!address || address.length < (start + end)) return address;
            return `${address.slice(0, start)}...${address.slice(-end)}`;
        },
        showToast(message, type = 'success') {
            let container = document.querySelector('.toast-container');
            if (!container) {
                container = document.createElement('div');
                container.className = 'toast-container';
                document.body.appendChild(container);
            }

            const toast = document.createElement('div');
            toast.className = `toast ${type}`;
            toast.innerHTML = `
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    ${type === 'success'
                        ? '<path d="M20 6L9 17l-5-5"/>'
                        : '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6"x2="18" y2="18"/>'
                    }
                </svg>
                <span>${message}</span>
            `;

            container.appendChild(toast);
            setTimeout(() => toast.classList.add('show'), 50);

            setTimeout(() => {
                toast.classList.remove('show');
                setTimeout(() => container.removeChild(toast), 300);
            }, 3000);
        },
        createLoadingState() {
            return `
                <div class="loading-shimmer" style="height: 24px; width: 100%; border-radius: 6px; margin-bottom: 12px;"></div>
                <div class="loading-shimmer" style="height: 80px; width: 100%; border-radius: 6px; margin-bottom: 12px;"></div>
                <div class="loading-shimmer" style="height: 120px; width: 100%; border-radius: 6px;"></div>
            `;
        }
    };

async function extractPnLData(iframe, timeframe) {
    try {
        await new Promise(resolve => setTimeout(resolve, 4000));

        const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
        const textContent = iframeDoc.body.innerText || '';

        console.log(`extractPnLData => timeframe=${timeframe}`);
        console.log('Scanning for PnL data...');

        let realizedPnL = 'N/A';
        let roi = 'N/A%';
        let realizedPnL_ROI = 'N/A';
        let winRate = 'N/A%';
        let tokensTraded = '0';
        let solInfo = '';

        // Debug: Print all text-14 elements to verify what we're finding
        console.log('\nDEBUG: All text-14 elements with profit/loss info:');
        const allProfitElements = iframeDoc.querySelectorAll('div[class*="text-14"][class*="font-bold"]');
        Array.from(allProfitElements).forEach((el, idx) => {
            console.log(`Element ${idx}:`, {
                text: el.innerText,
                classList: Array.from(el.classList)
            });
        });

        // Look for PnL value using text content first
        const pnlPattern = /Realized PnL \(ROI\)\s*\$([\d,k.]+)\s*\(([\d.-]+)%\)/i;
        const textMatch = textContent.match(pnlPattern);
        if (textMatch) {
            realizedPnL = `$${textMatch[1]}`;
            roi = `${textMatch[2]}%`;
            realizedPnL_ROI = `${realizedPnL} (${roi})`;
            console.log('Found PnL from text content:', realizedPnL_ROI);
        }

        // If not found in text, look for the specific element
        if (realizedPnL_ROI === 'N/A') {
            // This gets both green and red values
            const pnlElements = Array.from(iframeDoc.querySelectorAll('div.text-14.font-bold'));

            for (const el of pnlElements) {
                const rawText = el.innerText.trim();
                console.log('Checking element:', rawText);

                // Match both formats: "$23.34K (18.58%)" and "$23,342 (18.58%)"
                const match = rawText.match(/\$([\d,k.]+)\s*\(([\d.,-]+)%\)/i);
                if (match) {
                    realizedPnL_ROI = rawText;  // Use the exact text as displayed
                    realizedPnL = `$${match[1]}`;
                    roi = `${match[2]}%`;
                    console.log('Found PnL from element:', { realizedPnL_ROI, raw: rawText });
                    break;
                }
            }
        }

        // Extract Win Rate
        const winrateMatch = textContent.match(/Token Winrate\s*([\d.]+)%/i) ||
                            textContent.match(/Winrate[^0-9]*([\d.]+)%/i);
        if (winrateMatch) {
            winRate = `${winrateMatch[1]}%`;
            console.log('Found Win Rate:', winRate);
        }

        // Extract Tokens Traded
        const tradedMatch = textContent.match(/Traded\s*(\d+)/i);
        if (tradedMatch) {
            tokensTraded = tradedMatch[1];
            console.log('Found Tokens Traded:', tokensTraded);
        }

        // Extract SOL Balance from text content
        const solMatch = textContent.match(/Balance:\s*([\d.]+)\s*SOL\s*\((\$[\d,\.]+)\)/i);
        if (solMatch) {
            solInfo = `${solMatch[1]} SOL ${solMatch[2]}`;
            console.log('Found SOL Info:', solInfo);
        }

        console.log('\n=== Final Extraction Results ===');
        console.log('Timeframe:', timeframe);
        console.log('Realized PnL (ROI):', realizedPnL_ROI);
        console.log('Win Rate:', winRate);
        console.log('Tokens Traded:', tokensTraded);
        console.log('SOL Info:', solInfo);
        console.log('=== End Results ===\n');

        return {
            realizedPnL,
            roi,
            realizedPnL_ROI,
            winRate,
            tokensTraded,
            timeframe,
            timestamp: new Date().toISOString(),
            solInfo
        };
    } catch (error) {
        console.error('Error extracting PnL data:', error);
        return {
            error: 'Failed to extract data',
            details: error.message
        };
    }
}
    // -------------- 4) Process Wallet --------------
    async function processWallet(address, timeframe) {
        let iframe;
        try {
            const timeframeParam = timeframe === 'max' ? 'max' : timeframe;
            const profileUrl = `https://app.cielo.finance/profile/${address}/pnl/tokens?timeframe=${timeframeParam}`;

            iframe = document.createElement('iframe');
            iframe.style.display = 'none';
            document.body.appendChild(iframe);

            let loadTimeout;
            const loadPromise = new Promise((resolve, reject) => {
                iframe.onload = resolve;
                iframe.onerror = reject;
                loadTimeout = setTimeout(() => {
                    reject(new Error('Iframe loading timed out'));
                }, 10000);
            });

            iframe.src = profileUrl;
            await loadPromise;
            clearTimeout(loadTimeout);

            await new Promise(r => setTimeout(r, 4000));

            const data = await extractPnLData(iframe, timeframe);
            return {
                address,
                ...data,
                url: profileUrl
            };
        } catch (error) {
            console.error(`Error processing wallet ${address}:`, error);
            return {
                address,
                timeframe,
                error: 'Failed to process wallet',
                details: error.message
            };
        } finally {
            if (iframe) {
                try {
                    document.body.removeChild(iframe);
                } catch (err) {
                    console.warn('Could not remove iframe:', err);
                }
            }
        }
    }

    // -------------- 5) Process Multiple Wallets --------------


    const RATE_LIMIT = {
    delay: 2000,  // Base delay between requests
    maxRetries: 3,
    backoffFactor: 1.5
};

async function wait(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function processWalletWithRetry(address, timeframe, retryCount = 0) {
    try {
        // Add exponential backoff
        const currentDelay = RATE_LIMIT.delay * Math.pow(RATE_LIMIT.backoffFactor, retryCount);
        await wait(currentDelay);

        const data = await processWallet(address, timeframe);

        // If successful, return immediately
        if (!data.error) {
            return data;
        }

        // Handle rate limiting
        if (retryCount < RATE_LIMIT.maxRetries &&
            (data.error.includes('429') || data.error.includes('403'))) {
            console.log(`Rate limited, retrying in ${currentDelay}ms...`);
            return processWalletWithRetry(address, timeframe, retryCount + 1);
        }

        return data;
    } catch (error) {
        console.error(`Error processing wallet ${address}:`, error);
        return {
            address,
            timeframe,
            error: 'Failed to process wallet',
            details: error.message
        };
    }
}

async function processWallets(addresses) {
    const timeframes = ['1d', '7d', '30d', 'max'];
    const results = [];

    // Process wallets in parallel with rate limiting
    const processWalletAllTimeframes = async (address) => {
        const walletResults = [];
        for (const tf of timeframes) {
            const data = await processWalletWithRetry(address.trim(), tf);
            walletResults.push(data);

            // Add small delay between timeframes
            await wait(500);
        }
        return walletResults;
    };

    // Process wallets in chunks to avoid overwhelming
    const CHUNK_SIZE = 3;
    for (let i = 0; i < addresses.length; i += CHUNK_SIZE) {
        const chunk = addresses.slice(i, i + CHUNK_SIZE);
        const chunkResults = await Promise.all(
            chunk.map(address => processWalletAllTimeframes(address))
        );
        results.push(...chunkResults.flat());

        // Add delay between chunks
        if (i + CHUNK_SIZE < addresses.length) {
            await wait(3000);
        }
    }

    return results;
}

// Add progress tracking
function updateProgress(current, total, ui) {
    const progress = Math.round((current / total) * 100);
    ui.trackButton.innerHTML = `
        <svg class="rotating" viewBox="0 0 24 24" width="18" height="18" stroke="currentColor" fill="none" stroke-width="2">
            <circle cx="12" cy="12" r="10"/>
            <path d="M16 12h-4"/>
        </svg>
        Processing... ${progress}%
    `;
}

    // -------------- 6) Create Wallet Card UI --------------
function createWalletCard(data) {
    const card = document.createElement('div');
    card.className = 'wallet-card';

    function getWinRateBadgeClass(rate) {
        if (!rate || rate === 'N/A') return 'medium';
        const val = parseFloat(rate);
        if (val >= 65) return 'high';
        if (val >= 50) return 'medium';
        return 'low';
    }

    function isNegative(val) {
        if (!val || val === 'N/A') return false;
        return `${val}`.includes('-');
    }

    const pnlClass = isNegative(data.realizedPnL_ROI) ? 'negative' : 'positive';
    let solString = '';
    if (data.solInfo) {
        const match = data.solInfo.match(/([\d\.]+)\s*SOL\s*\$([\d,\.]+)/i);
        if (match) {
            solString = `${match[1]} SOL (~$${match[2]})`;
        } else {
            solString = data.solInfo;
        }
    }

    // Create timeframe tabs
    const tabs = document.createElement('div');
    tabs.className = 'timeframe-tabs';
    tabs.innerHTML = `
        <button class="timeframe-tab" data-timeframe="1d">1D</button>
        <button class="timeframe-tab" data-timeframe="7d">7D</button>
        <button class="timeframe-tab active" data-timeframe="30d">30D</button>
        <button class="timeframe-tab" data-timeframe="max">MAX</button>
    `;

    card.innerHTML = `
        <div class="wallet-header">
            <div class="wallet-address-container">
                <span class="wallet-address" title="${data.address}">
                    ${utils.truncateAddress(data.address)}
                </span>
                ${solString ? `<span class="sol-info">${solString}</span>` : ''}
            </div>
            <div class="wallet-actions">
                <button class="wallet-action-btn view-cielo" data-tooltip="View on Cielo">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>
                        <polyline points="15 3 21 3 21 9"/>
                        <line x1="10" y1="14" x2="21" y2="3"/>
                    </svg>
                </button>
                <button class="wallet-action-btn view-solscan" data-tooltip="View on Solscan">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="12" cy="12" r="10"/>
                        <line x1="12" y1="8" x2="12" y2="16"/>
                        <line x1="8" y1="12" x2="16" y2="12"/>
                    </svg>
                </button>
                <button class="wallet-action-btn copy-address" data-tooltip="Copy Address">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                        <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
                    </svg>
                </button>
            </div>
        </div>
        <div class="stats-grid">
            <div class="stat-card" style="grid-column: span 2">
                <span class="stat-label">Realized PnL (ROI)</span>
                <span class="stat-value ${pnlClass}">
                    ${data.realizedPnL_ROI || 'N/A'}
                </span>
            </div>
            <div class="stat-card">
                <span class="stat-label">Win Rate</span>
                <div class="winrate-badge ${getWinRateBadgeClass(data.winRate)}">
                    ${data.winRate || 'N/A'}
                </div>
            </div>
            <div class="stat-card">
                <span class="stat-label">Tokens</span>
                <span class="stat-value">
                    ${data.tokensTraded === 'N/A' ? '0' : data.tokensTraded}
                </span>
            </div>
        </div>
    `;

    // Insert tabs at the beginning of the card
    card.insertBefore(tabs, card.firstChild);

    // Add event listeners
    const viewCieloBtn = card.querySelector('.view-cielo');
    viewCieloBtn.addEventListener('click', () => {
        const timeframe = card.querySelector('.timeframe-tab.active').dataset.timeframe;
        const url = `https://app.cielo.finance/profile/${data.address}/pnl/tokens?timeframe=${timeframe}`;
        window.open(url, '_blank');
    });

    const viewSolscanBtn = card.querySelector('.view-solscan');
    viewSolscanBtn.addEventListener('click', () => {
        const url = `https://solscan.io/account/${data.address}#defiactivities`;
        window.open(url, '_blank');
    });

    const copyBtn = card.querySelector('.copy-address');
    copyBtn.addEventListener('click', () => {
        navigator.clipboard.writeText(data.address).then(() => {
            utils.showToast('Address copied to clipboard', 'success');
        });
    });

    return card;
}
    // -------------- 7) Display Results --------------
function displayResults(allData, container) {
    container.innerHTML = '';

    // Group wallets based on 30d win rate
    const getWinRate = (data) => {
        const wallet30d = data.find(d => d.timeframe === '30d');
        if (!wallet30d || !wallet30d.winRate) return 0;
        return parseFloat(wallet30d.winRate.replace('%', ''));
    };

    // Group wallets by address first
    const walletGroups = {};
    allData.forEach(item => {
        if (!walletGroups[item.address]) {
            walletGroups[item.address] = [];
        }
        walletGroups[item.address].push(item);
    });

    // Sort wallets into performance groups
    const performanceGroups = {
        winners: [],
        average: [],
        losers: []
    };

    Object.entries(walletGroups).forEach(([address, data]) => {
        const winRate = getWinRate(data);
        if (winRate >= 60) {
            performanceGroups.winners.push(data);
        } else if (winRate >= 50 && winRate < 60) {
            performanceGroups.average.push(data);
        } else if (winRate < 40) {
            performanceGroups.losers.push(data);
        }
    });

    // Create sections for each group
    const groupTitles = {
        winners: 'High Performers (>60% Win Rate)',
        average: 'Average Performers (50-60% Win Rate)',
        losers: 'Underperformers (<40% Win Rate)'
    };

    Object.entries(performanceGroups).forEach(([group, wallets]) => {
        if (wallets.length === 0) return;

        const section = document.createElement('div');
        section.className = 'performance-group';

        // Create collapsible header with copy button
        const header = document.createElement('div');
        header.className = 'group-header';
        header.innerHTML = `
            <div class="group-title-container">
                <svg class="toggle-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="6 9 12 15 18 9"></polyline>
                </svg>
                <h3 class="group-title">${groupTitles[group]}</h3>
                <span class="wallet-count">${wallets.length} wallets</span>
            </div>
            <div class="group-actions">
<button class="copy-wallets-btn" data-tooltip="Copy All Addresses">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                        <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                    </svg>
                </button>
            </div>
        `;

        const walletsContainer = document.createElement('div');
        walletsContainer.className = 'group-wallets';

        // Add click handler for collapse/expand
        header.addEventListener('click', (e) => {
            if (!e.target.closest('.copy-wallets-btn')) {
                header.classList.toggle('collapsed');
                walletsContainer.classList.toggle('collapsed');
            }
        });

        // Add click handler for copy button
        const copyButton = header.querySelector('.copy-wallets-btn');
        copyButton.addEventListener('click', (e) => {
            e.stopPropagation();
            const addresses = wallets.map(wallet => wallet[0].address).join('\n');
            navigator.clipboard.writeText(addresses).then(() => {
                utils.showToast(`Copied ${wallets.length} addresses to clipboard`, 'success');
            }).catch(() => {
                utils.showToast('Failed to copy addresses', 'error');
            });
        });

        // Create wallet cards
        wallets.forEach(walletData => {
            const defaultData = walletData.find(d => d.timeframe === '30d') || walletData[0];
            const card = createWalletCard(defaultData);

            // Add tab switching logic
            const tabs = card.querySelector('.timeframe-tabs');
            tabs.addEventListener('click', (e) => {
                if (e.target.classList.contains('timeframe-tab')) {
                    const tf = e.target.dataset.timeframe;
                    const newData = walletData.find(d => d.timeframe === tf);

                    if (newData) {
                        // Update all stats at once
                        const pnlElement = card.querySelector('.stat-card .stat-value');
                        const winRateElement = card.querySelector('.winrate-badge');
                        const tokensElement = card.querySelector('.stat-card:last-child .stat-value');

                        // Update PnL with correct color
                        if (newData.realizedPnL_ROI) {
                            pnlElement.textContent = newData.realizedPnL_ROI;
                            pnlElement.className = `stat-value ${newData.realizedPnL_ROI.includes('-') ? 'negative' : 'positive'}`;
                        } else {
                            pnlElement.textContent = 'N/A';
                            pnlElement.className = 'stat-value';
                        }

                        // Update Win Rate with correct badge class
                        if (newData.winRate) {
                            winRateElement.textContent = newData.winRate;
                            const winRateValue = parseFloat(newData.winRate);
                            let badgeClass = 'medium';
                            if (winRateValue >= 65) badgeClass = 'high';
                            else if (winRateValue < 50) badgeClass = 'low';
                            winRateElement.className = `winrate-badge ${badgeClass}`;
                        } else {
                            winRateElement.textContent = 'N/A';
                            winRateElement.className = 'winrate-badge medium';
                        }

                        // Update Tokens count
                        tokensElement.textContent = newData.tokensTraded || '0';
                    }

                    // Update active tab state
                    tabs.querySelectorAll('.timeframe-tab').forEach(t =>
                        t.classList.toggle('active', t === e.target)
                    );
                }
            });

            walletsContainer.appendChild(card);
        });

        section.appendChild(header);
        section.appendChild(walletsContainer);
        container.appendChild(section);
    });
}
    // -------------- 8) Create Main UI --------------
    function createUI() {
        const container = document.createElement('div');
        container.className = 'cielo-tracker';

        container.innerHTML = `
            <div class="bubble-icon">📊</div>
            <div class="cielo-header">
                <div class="header-title">
                    <svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" fill="none" stroke-width="2">
                        <path d="M12 20V10M18 20V4M6 20v-4"/>
                    </svg>
                    Cielo PnL Tracker
                </div>
                <button class="minimize-button">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="5" y1="12" x2="19" y2="12"/>
                    </svg>
                </button>
            </div>
            <div class="tracker-content">
                <div class="input-section">
                    <textarea class="wallet-textarea"
                        placeholder="Enter wallet addresses (one per line)"></textarea>
                    <button class="action-button">
                        <svg viewBox="0 0 24 24" width="18" height="18" stroke="currentColor" fill="none" stroke-width="2">
                            <circle cx="12" cy="12" r="10"/>
                            <path d="M12 16v-4M12 8h.01"/>
                        </svg>
                        Start Tracking
                    </button>
                </div>
                <div class="results-container"></div>
            </div>
        `;

        document.body.appendChild(container);

        const ui = {
            container,
            bubbleIcon: container.querySelector('.bubble-icon'),
            minimizeButton: container.querySelector('.minimize-button'),
            textarea: container.querySelector('.wallet-textarea'),
            trackButton: container.querySelector('.action-button'),
            resultsContainer: container.querySelector('.results-container')
        };

        // Minimize/Maximize functionality
        ui.minimizeButton.addEventListener('click', () => {
            container.classList.add('minimized');
        });
        ui.bubbleIcon.addEventListener('click', () => {
            container.classList.remove('minimized');
        });

        // Start tracking functionality
ui.trackButton.addEventListener('click', async () => {
    if (ui.trackButton.disabled) return;

    const addresses = ui.textarea.value
        .split('\n')
        .map(a => a.trim())
        .filter(Boolean);

    if (!addresses.length) {
        utils.showToast('Please enter at least one wallet address', 'error');
        return;
    }

    ui.trackButton.disabled = true;
    ui.resultsContainer.innerHTML = utils.createLoadingState();

    try {
        let processedCount = 0;
        const totalOperations = addresses.length * 4; // 4 timeframes per address

        const results = await processWallets(addresses, (count) => {
            processedCount += count;
            updateProgress(processedCount, totalOperations, ui);
        });

        const timestamp = new Date().toISOString();
        scanHistory[timestamp] = { data: results, addresses };
        GM_setValue(HISTORY_KEY, scanHistory);

        displayResults(results, ui.resultsContainer);
        utils.showToast('Scan completed successfully!', 'success');
        ui.textarea.value = '';
    } catch (err) {
        console.error('Error in Start Tracking:', err);
        utils.showToast('An error occurred during scanning', 'error');
        ui.resultsContainer.innerHTML = `
            <div style="text-align: center; padding: 20px; color: rgba(255,255,255,0.6);">
                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="10"/>
                    <line x1="12" y1="8" x2="12" y2="12"/>
                    <line x1="12" y1="16" x2="12.01" y2="16"/>
                </svg>
                <p>Failed to process wallets. Please try again.</p>
            </div>
        `;
    } finally {
        ui.trackButton.disabled = false;
        ui.trackButton.innerHTML = `
            <svg viewBox="0 0 24 24" width="18" height="18" stroke="currentColor" fill="none" stroke-width="2">
                <circle cx="12" cy="12" r="10"/>
                <path d="M12 16v-4M12 8h.01"/>
            </svg>
            Start Tracking
        `;
    }
});

        return ui;
    }

    // -------------- 9) Add Drag & Drop Support --------------
    function addDragAndDrop(ui) {
        let isDragging = false;
        let startX, startY, xOffset = 0, yOffset = 0;

        const onMouseDown = (e) => {
            if (e.target.closest('.cielo-header')) {
                isDragging = true;
                startX = e.clientX - xOffset;
                startY = e.clientY - yOffset;
            }
        };

        const onMouseMove = (e) => {
            if (!isDragging) return;
            xOffset = e.clientX - startX;
            yOffset = e.clientY - startY;
            ui.container.style.transform = `translate(${xOffset}px, ${yOffset}px)`;
        };

        const onMouseUp = () => {
            isDragging = false;
        };

        ui.container.addEventListener('mousedown', onMouseDown);
        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);
    }

    // -------------- 10) Add Keyboard Shortcuts --------------
    function addKeyboardShortcuts(ui) {
        document.addEventListener('keydown', (e) => {
            // Ctrl/Cmd + M => toggle minimized
            if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'm') {
                e.preventDefault();
                ui.container.classList.toggle('minimized');
            }
            // Esc => minimize
            if (e.key === 'Escape' && !ui.container.classList.contains('minimized')) {
                ui.container.classList.add('minimized');
            }
        });
    }

    // -------------- 11) Initialize --------------
    function init() {
        console.log('Enhanced Cielo Tracker: Initializing...');
        if (document.querySelector('.cielo-tracker')) {
            console.log('Already initialized.');
            return;
        }
        const ui = createUI();
        addDragAndDrop(ui);
        addKeyboardShortcuts(ui);
        console.log('Enhanced Cielo Tracker: Initialized successfully');
    }

    // Start initialization
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();