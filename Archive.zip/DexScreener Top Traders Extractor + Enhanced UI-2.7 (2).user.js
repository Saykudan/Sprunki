// ==UserScript==
// @name         DexScreener Top Traders Extractor + Enhanced UI
// @namespace    http://tampermonkey.net/
// @version      2.7
// @description  Enhanced UI for DexScreener top traders extraction
// @match        https://dexscreener.com/*
// @grant        GM_addStyle
// ==/UserScript==

(function() {
    'use strict';

    console.log('[DexScreener + Enhanced] Starting initialization...');

    // Enhanced Styles
GM_addStyle(`
    .dex-traders-tracker {
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 9999;
        background: rgba(17, 25, 40, 0.95);
        backdrop-filter: blur(8px);
        padding: 20px;
        border-radius: 16px;
        border: 1px solid rgba(255, 255, 255, 0.1);
        width: 520px;
        font-family: system-ui, -apple-system, sans-serif;
        max-height: 90vh;
        overflow-y: auto;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        color: #E5E7EB;
    }

    .dex-traders-tracker::-webkit-scrollbar {
        width: 8px;
    }

    .dex-traders-tracker::-webkit-scrollbar-track {
        background: rgba(255, 255, 255, 0.05);
        border-radius: 4px;
    }

    .dex-traders-tracker::-webkit-scrollbar-thumb {
        background: rgba(255, 255, 255, 0.1);
        border-radius: 4px;
    }

    .dex-traders-tracker::-webkit-scrollbar-thumb:hover {
        background: rgba(255, 255, 255, 0.2);
    }

    .dex-traders-tracker.minimized {
        width: 50px;
        height: 50px;
        padding: 0;
        border-radius: 25px;
        overflow: hidden;
        cursor: pointer;
        background: #10B981;
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: 0 2px 10px rgba(16, 185, 129, 0.2);
    }

    .traders-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 16px;
        padding-bottom: 16px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }

    .traders-header strong {
        font-size: 1.2em;
        color: #fff;
        font-weight: 600;
    }

    .minimize-button {
        cursor: pointer;
        padding: 8px;
        border-radius: 8px;
        color: rgba(255, 255, 255, 0.8);
        background: rgba(255, 255, 255, 0.05);
        display: inline-flex;
        align-items: center;
        gap: 5px;
        transition: all 0.2s ease;
    }

    .minimize-button:hover {
        background: rgba(255, 255, 255, 0.1);
        transform: scale(1.05);
    }

    /* Token Info Styles */
    .token-info-container {
        background: rgba(255, 255, 255, 0.05);
        border-radius: 12px;
        padding: 16px;
        margin-bottom: 16px;
        border: 1px solid rgba(255, 255, 255, 0.1);
    }

    .token-metadata {
        display: flex;
        flex-direction: column;
        gap: 16px;
    }

    .token-header {
        display: flex;
        align-items: center;
        gap: 12px;
        margin-bottom: 12px;
    }

    .token-name {
        font-size: 1.5em;
        font-weight: 700;
        color: #fff;
    }

    .chain-badge {
        background: linear-gradient(135deg, #10B981, #059669);
        color: white;
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 0.85em;
        font-weight: 500;
    }

    .token-address-container {
        background: rgba(17, 25, 40, 0.7);
        border-radius: 8px;
        padding: 12px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
    }

    .token-address {
        font-family: 'Roboto Mono', monospace;
        font-size: 0.9em;
        color: #fff;
        flex: 1;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }

    .copy-address-btn {
        background: linear-gradient(135deg, #10B981, #059669);
        color: white;
        border: none;
        border-radius: 6px;
        padding: 8px 16px;
        font-size: 0.9em;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 6px;
        transition: all 0.2s ease;
    }

    .copy-address-btn:hover {
        background: linear-gradient(135deg, #059669, #047857);
        transform: translateY(-1px);
    }

    .metadata-details {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
        gap: 12px;
        margin-top: 12px;
    }

    .metadata-item {
        background: rgba(17, 25, 40, 0.7);
        border-radius: 12px;
        padding: 16px;
        display: flex;
        flex-direction: column;
        gap: 8px;
        border: 1px solid rgba(255, 255, 255, 0.1);
        transition: all 0.2s ease;
    }

    .metadata-item:hover {
        transform: translateY(-2px);
        background: rgba(255, 255, 255, 0.05);
    }

    .metadata-item.dex-stat { background: rgba(33, 150, 243, 0.1); }
    .metadata-item.age-stat { background: rgba(156, 39, 176, 0.1); }
    .metadata-item.rank-stat { background: rgba(255, 152, 0, 0.1); }
    .metadata-item.volume-stat { background: rgba(76, 175, 80, 0.1); }

    .metadata-label {
        color: rgba(255, 255, 255, 0.6);
        font-size: 0.85em;
        font-weight: 500;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    .metadata-value {
        color: #fff;
        font-size: 1.2em;
        font-weight: 600;
    }

    /* Filter Section */
    .filter-section {
        background: rgba(255, 255, 255, 0.05);
        border-radius: 12px;
        margin-bottom: 16px;
        overflow: hidden;
        transition: all 0.3s ease;
        border: 1px solid rgba(255, 255, 255, 0.1);
    }

    .filter-header {
        padding: 12px 16px;
        background: rgba(255, 255, 255, 0.02);
        display: flex;
        justify-content: space-between;
        align-items: center;
        cursor: pointer;
        user-select: none;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }

    .filter-header:hover {
        background: rgba(255, 255, 255, 0.05);
    }

    .filter-title {
        font-weight: 600;
        color: #fff;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .filter-toggle {
        transition: transform 0.3s ease;
    }

    .filter-section.collapsed .filter-toggle {
        transform: rotate(-180deg);
    }

    .filter-content {
        padding: 16px;
        max-height: 500px;
        transition: all 0.3s ease;
        opacity: 1;
    }

    .filter-section.collapsed .filter-content {
        max-height: 0;
        padding: 0 16px;
        opacity: 0;
        pointer-events: none;
    }

    .filter-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 16px;
    }

    .filter-group {
        display: flex;
        flex-direction: column;
        gap: 8px;
    }

    .filter-label {
        font-size: 0.85em;
        color: rgba(255, 255, 255, 0.6);
        font-weight: 500;
        display: flex;
        align-items: center;
        gap: 4px;
    }

    .filter-input {
        padding: 8px 12px;
        background: rgba(17, 25, 40, 0.7);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 6px;
        font-size: 0.9em;
        color: #fff;
        transition: all 0.2s ease;
    }

    .filter-input:focus {
        outline: none;
        border-color: #10B981;
        box-shadow: 0 0 0 2px rgba(16, 185, 129, 0.1);
    }

    .filter-actions {
        display: flex;
        gap: 12px;
        margin-top: 16px;
    }

    .filter-button {
        padding: 10px 16px;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        font-weight: 500;
        transition: all 0.2s ease;
        flex: 1;
    }

    .apply-filters {
        background: linear-gradient(135deg, #10B981, #059669);
        color: white;
    }

    .reset-filters {
        background: rgba(255, 255, 255, 0.1);
        color: rgba(255, 255, 255, 0.8);
    }

    .filter-button:hover {
        transform: translateY(-1px);
    }

    .apply-filters:hover {
        background: linear-gradient(135deg, #059669, #047857);
    }

    .reset-filters:hover {
        background: rgba(255, 255, 255, 0.15);
    }

    .filter-status {
        font-size: 0.85em;
        color: rgba(255, 255, 255, 0.6);
        text-align: right;
        margin-top: 8px;
        padding: 0 16px;
    }

    .track-button {
        width: 100%;
        padding: 12px;
        background: linear-gradient(135deg, #10B981, #059669);
        color: white;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        font-weight: 600;
        font-size: 1em;
        margin: 16px 0;
        transition: all 0.2s ease;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
    }

    .track-button:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
    }

    .track-button:disabled {
        background: rgba(255, 255, 255, 0.1);
        cursor: not-allowed;
        transform: none;
        box-shadow: none;
    }

    .track-button svg {
        width: 18px;
        height: 18px;
    }

    /* Helper Classes */
    .value-up { color: #10B981; }
    .value-down { color: #EF4444; }

    /* Misc Icons */
    .bubble-icon {
        width: 48px;
        height: 48px;
        border-radius: 50%;
        display: none;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 24px;
        background: linear-gradient(135deg, #10B981, #059669);
    }

    .dex-traders-tracker.minimized .bubble-icon {
        display: flex !important;
    }
    .trader-result {
    background: rgba(17, 25, 40, 0.7);
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 16px;
    padding: 20px;
    margin-bottom: 16px;
    transition: all 0.2s ease;
}

.trader-result:hover {
    transform: translateY(-2px);
    background: rgba(255, 255, 255, 0.05);
}

.wallet-info {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 16px;
    padding-bottom: 16px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
}

.rank-badge {
    background: linear-gradient(135deg, #10B981, #059669);
    color: white;
    padding: 6px 12px;
    border-radius: 20px;
    font-size: 0.9em;
    font-weight: 600;
    box-shadow: 0 2px 4px rgba(16, 185, 129, 0.2);
}

.wallet-address {
    display: flex;
    align-items: center;
    gap: 8px;
    font-family: 'Courier New', monospace;
    background: rgba(17, 25, 40, 0.7);
    padding: 8px 12px;
    border-radius: 8px;
    color: #fff;
    font-size: 0.9em;
}

.wallet-links {
    display: flex;
    gap: 8px;
}

.wallet-button {
    background: transparent;
    border: 1px solid #10B981;
    color: #10B981;
    padding: 6px 10px;
    border-radius: 6px;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 4px;
    transition: all 0.2s ease;
}

.wallet-button:hover {
    background: #10B981;
    color: white;
}

.trading-stats {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 12px;
    margin-top: 12px;
}

.stat-box {
    background: rgba(17, 25, 40, 0.7);
    padding: 16px;
    border-radius: 12px;
    display: flex;
    flex-direction: column;
    gap: 8px;
    border: 1px solid rgba(255, 255, 255, 0.1);
    transition: all 0.2s ease;
}

.stat-box:hover {
    transform: translateY(-2px);
    background: rgba(255, 255, 255, 0.05);
}

.stat-label {
    font-size: 0.85em;
    color: rgba(255, 255, 255, 0.6);
    text-transform: uppercase;
    letter-spacing: 0.5px;
    font-weight: 500;
}

.stat-value {
    font-size: 1.2em;
    font-weight: 600;
    color: #fff;
}

.bought-value {
    color: #10B981;
}

.sold-value {
    color: #EF4444;
}

.txn-count {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    background: rgba(255, 255, 255, 0.05);
    padding: 4px 8px;
    border-radius: 12px;
    font-size: 0.75em;
    color: rgba(255, 255, 255, 0.6);
}

.pnl-positive {
    color: #10B981;
}

.pnl-negative {
    color: #EF4444;
}

.trader-icon {
    width: 16px;
    height: 16px;
}

.action-icon {
    width: 14px;
    height: 14px;
    opacity: 0.7;
}

.track-button.copy-all {
    background: linear-gradient(135deg, #10B981, #059669);
}

.track-button.copy-all:hover {
    background: linear-gradient(135deg, #059669, #047857);
}
`);

    // State
    let lastUrl = location.href;
    let urlChangeInProgress = false;
    let ui = null;

    // Utility Functions
    function truncateWallet(wallet, length = 6) {
        if (!wallet || wallet.length < 12) return wallet;
        return `${wallet.slice(0, length)}...${wallet.slice(-4)}`;
    }

    function formatNumber(num) {
        if (typeof num !== 'number' || isNaN(num)) return '0';
        if (num >= 1e9) return (num / 1e9).toFixed(2) + 'B';
        if (num >= 1e6) return (num / 1e6).toFixed(2) + 'M';
        if (num >= 1e3) return (num / 1e3).toFixed(2) + 'K';
        return num.toFixed(2);
    }

    function formatCurrency(value) {
        if (value === 'N/A') return 'N/A';
        const numStr = value.replace(/[$,]/g, '');
        const num = parseFloat(numStr);
        if (isNaN(num)) return value;

        const absNum = Math.abs(num);
        if (absNum >= 1e9) {
            return `$${(num / 1e9).toFixed(2)}B`;
        } else if (absNum >= 1e6) {
            return `$${(num / 1e6).toFixed(2)}M`;
        } else if (absNum >= 1e3) {
            return `$${(num / 1e3).toFixed(1)}K`;
        }
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD',
            minimumFractionDigits: 0,
            maximumFractionDigits: 0
        }).format(num);
    }

    function formatTransactions(txns) {
        if (txns === 'N/A' || txns === '0') return '0';
        const num = parseInt(txns.replace(/[^\d]/g, ''));
        if (isNaN(num)) return txns;
        if (num >= 1000) return `${(num/1000).toFixed(1)}k`;
        return num.toString();
    }

    async function waitForTopTradersButton(maxAttempts = 15) {
        return new Promise((resolve) => {
            let attempts = 0;
            const checkButton = () => {
                attempts++;

                // Try to find the exact button structure
                const topTradersButtons = Array.from(document.querySelectorAll('button.chakra-button'))
                    .filter(button => {
                        const iconSpan = button.querySelector('span.chakra-button__icon');
                        const svg = button.querySelector('svg.chakra-icon');
                        const hasTopTradersText = button.textContent.includes('Top Traders');

                        return iconSpan && svg && hasTopTradersText;
                    });

                if (topTradersButtons.length > 0) {
                    console.log('[DexScreener Enhanced] Found exact Top Traders button match');
                    resolve(topTradersButtons[0]);
                    return;
                }

                const fallbackButtons = Array.from(document.querySelectorAll('button'))
                    .filter(button => button.textContent.includes('Top Traders'));

                if (fallbackButtons.length > 0) {
                    console.log('[DexScreener Enhanced] Found fallback Top Traders button');
                    resolve(fallbackButtons[0]);
                    return;
                }

                if (attempts >= maxAttempts) {
                    console.log('[DexScreener Enhanced] Button not found after', maxAttempts, 'attempts');
                    resolve(null);
                    return;
                }

                setTimeout(checkButton, 1000);
            };
            checkButton();
        });
    }

async function ensureTopTradersTabOpen() {
        try {
            console.log('[DexScreener Enhanced] Looking for Top Traders button...');
            const button = await waitForTopTradersButton();

            if (!button) {
                console.log('[DexScreener Enhanced] Top Traders button not found');
                return false;
            }

            const isAlreadySelected = button.getAttribute('aria-selected') === 'true' ||
                                    button.classList.contains('active') ||
                                    button.parentElement?.classList.contains('active');

            if (isAlreadySelected) {
                console.log('[DexScreener Enhanced] Already on Top Traders tab');
                return true;
            }

            console.log('[DexScreener Enhanced] Clicking Top Traders button...');
            button.click();

            // Fixed the syntax error here
            await new Promise(resolve => setTimeout(resolve, 3000));

            return true;
        } catch (err) {
            console.error('[DexScreener Enhanced] Error in ensureTopTradersTabOpen:', err);
            return false;
        }
    }

    function waitForElement(selector, maxAttempts = 10, interval = 1000) {
        return new Promise((resolve, reject) => {
            let attempts = 0;
            const check = () => {
                attempts++;
                const element = document.querySelector(selector);
                if (element) {
                    resolve(element);
                    return;
                }
                if (attempts >= maxAttempts) {
                    reject(new Error(`Element ${selector} not found after ${maxAttempts} attempts`));
                    return;
                }
                setTimeout(check, interval);
            };
            check();
        });
    }

    function watchUrlChanges(intervalMs = 1500) {
        setInterval(() => {
            if (location.href !== lastUrl && !urlChangeInProgress) {
                lastUrl = location.href;
                urlChangeInProgress = true;
                console.log('[DexScreener Enhanced] Detected URL change => refetch new data');
                startShimmer(ui.tokenInfoContainer);
                setTimeout(() => {
                    const metadata = extractPageMetadata();
                    displayMetadata(metadata, ui.tokenInfoContainer);
                    stopShimmer(ui.tokenInfoContainer);
                    urlChangeInProgress = false;
                }, 2000);
            }
        }, intervalMs);
    }

    function startShimmer(element) {
        element.innerHTML = `<div class="token-metadata shimmer" style="height:100px; border-radius:8px;"></div>`;
    }

    function stopShimmer(element) {
        // Shimmer removed by displayMetadata
    }

    function extractPageMetadata() {
        const metadata = {
            chain: 'Unknown',
            dex: 'Unknown',
            token: 'Unknown',
            tokenAddress: 'Unknown',
            tokenAge: 'Unknown',
            tokenRank: 'Unknown',
            volume: 'Unknown',
            isTokenPage: false
        };

        try {
            const ogUrlTag = document.querySelector('meta[property="og:url"]');
            if (ogUrlTag) {
                const fullUrl = ogUrlTag.getAttribute('content');
                if (fullUrl) {
                    const urlObj = new URL(fullUrl);
                    const parts = urlObj.pathname.split('/').filter(Boolean);
                    if (parts.length >= 2) {
                        metadata.chain = parts[0];
                        metadata.tokenAddress = parts[1];
                        metadata.isTokenPage = true;
                    }
                }
            }

            if (metadata.chain === 'Unknown' || metadata.tokenAddress === 'Unknown') {
                const parts = location.pathname.split('/').filter(Boolean);
                if (parts.length >= 2) {
                    metadata.chain = parts[0];
                    metadata.tokenAddress = parts[1];
                    metadata.isTokenPage = true;
                }
            }

            const titleEl = document.querySelector('title[data-rh="true"]') || document.querySelector('title');
            if (titleEl) {
                const text = titleEl.textContent.trim();
                const onIndex = text.indexOf(' on ');
                if (onIndex !== -1) {
                    const afterOn = text.slice(onIndex + 4);
                    const dashParts = afterOn.split('-');
                    const chainDexPart = dashParts[0].trim();
                    const chainDex = chainDexPart.split('/').map(s => s.trim());
                    if (chainDex.length === 2) {
                        metadata.chain = chainDex[0];
                        metadata.dex = chainDex[1];
                    }
                }
                const tokenMatch = text.match(/^([\w\d-]+)/);
                if (tokenMatch) {
                    metadata.token = tokenMatch[1];
                }
            }

            const ageDiv = document.querySelector('.custom-ar71po');
            if (ageDiv) metadata.tokenAge = ageDiv.textContent.trim();

            const rankDiv = document.querySelector('.custom-r8w609');
            if (rankDiv) metadata.tokenRank = rankDiv.textContent.trim();

            const volumeDiv = document.querySelector('.custom-1urntjj');
            if (volumeDiv) metadata.volume = volumeDiv.textContent.trim();

        } catch (err) {
            console.error('[DexScreener Enhanced] Error extracting metadata:', err);
        }

        return metadata;
    }

function displayMetadata(metadata, container) {
    container.innerHTML = '';
    const div = document.createElement('div');
    div.className = 'token-metadata';
    div.innerHTML = `
        <div class="token-header">
            <span class="token-name">${metadata.token}</span>
            <span class="chain-badge">${metadata.chain}</span>
        </div>

        <div class="token-address-container">
            <span class="token-address">${metadata.tokenAddress}</span>
            <button class="copy-address-btn">
                <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none">
                    <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                    <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                </svg>
                Copy
            </button>
        </div>

        <div class="metadata-details">
            <div class="metadata-item dex-stat">
                <span class="metadata-label">DEX</span>
                <span class="metadata-value">${metadata.dex}</span>
            </div>
            <div class="metadata-item age-stat">
                <span class="metadata-label">Age</span>
                <span class="metadata-value">${metadata.tokenAge}</span>
            </div>
            <div class="metadata-item rank-stat">
                <span class="metadata-label">Rank</span>
                <span class="metadata-value">${metadata.tokenRank}</span>
            </div>
            <div class="metadata-item volume-stat">
                <span class="metadata-label">Volume</span>
                <span class="metadata-value">${metadata.volume}</span>
            </div>
        </div>
    `;
    container.appendChild(div);

    // Add copy button functionality
    const copyBtn = div.querySelector('.copy-address-btn');
    copyBtn.addEventListener('click', () => {
        const addr = metadata.tokenAddress;
        if (!addr || addr === 'Unknown') return;
        navigator.clipboard.writeText(addr).then(() => {
            copyBtn.innerHTML = `
                <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none">
                    <path d="M20 6L9 17l-5-5"></path>
                </svg>
                Copied!
            `;
            setTimeout(() => {
                copyBtn.innerHTML = `
                    <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none">
                        <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                        <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                    </svg>
                    Copy
                `;
            }, 2000);
        });
    });
}

    async function extractTopTraders() {
        try {
            console.log('[DexScreener Enhanced] Starting trader extraction...');

            // First ensure Top Traders tab is open
            const tabOpened = await ensureTopTradersTabOpen();
            if (!tabOpened) {
                console.log('Failed to open Top Traders tab');
                return [];
            }

            // Wait for trade data to load
            console.log('Waiting for trade data to load...');
            await new Promise(resolve => setTimeout(resolve, 2000));

            // Try multiple selectors for rows
            let rows = [];
            const rowSelectors = [
                '[role="row"]',
                '[class*="custom-1nvxwu0"]',
                'div[role="gridcell"]',
                'div[class*="custom-"] > a[aria-label="Open in block explorer"]'
            ];

            for (const selector of rowSelectors) {
                rows = document.querySelectorAll(selector);
                console.log(`Trying selector "${selector}" - found ${rows.length} rows`);
                if (rows.length > 0) break;
            }

            console.log(`Found ${rows.length} rows total`);

            const traders = [];
            for (const row of rows) {
                try {
                    const traderRow = row.closest('[class*="custom-"]') || row;
                    const explorerLink = traderRow.querySelector('a[aria-label="Open in block explorer"]') ||
                                       (row.tagName === 'A' ? row : null);

                    if (!explorerLink) {
                        console.log('No explorer link found in row, skipping');
                        continue;
                    }

                    const href = explorerLink.getAttribute('href') || '';
                    const wallet = href.split('/').pop() || 'UnknownWallet';
                    const rank = `#${traders.length + 1}`;

                    const tradeContainers = traderRow.querySelectorAll('.custom-1o79wax');
                    console.log(`Found ${tradeContainers.length} trade containers for wallet ${wallet}`);

                    // Process Bought Data
                    let bought = { usd: 'N/A', qty: 'N/A', txns: '0' };
                    const boughtContainer = tradeContainers[0];
                    if (boughtContainer) {
                        const boughtUsdEl = boughtContainer.querySelector('.custom-rcecxm');
                        if (boughtUsdEl) {
                            bought.usd = boughtUsdEl.textContent.trim();
                        }

                        const boughtQtyWrapper = boughtContainer.querySelector('.custom-13ppmr2');
                        if (boughtQtyWrapper) {
                            const qtySpans = boughtQtyWrapper.querySelectorAll('.custom-2ygcmq');
                            if (qtySpans.length >= 2) {
                                bought.qty = qtySpans[0].textContent.trim();
                                bought.txns = qtySpans[1].textContent.trim();
                            }
                        }
                    }

                    // Process Sold Data
                    let sold = { usd: 'N/A', qty: 'N/A', txns: '0' };
                    const soldContainer = tradeContainers[1];
                    if (soldContainer) {
                        const soldUsdEl = soldContainer.querySelector('.custom-dv3t8y');
                        if (soldUsdEl) {
                            sold.usd = soldUsdEl.textContent.trim();
                        }

                        const soldQtyWrapper = soldContainer.querySelector('.custom-13ppmr2');
                        if (soldQtyWrapper) {
                            const qtySpans = soldQtyWrapper.querySelectorAll('.custom-2ygcmq');
                            if (qtySpans.length >= 2) {
                                sold.qty = qtySpans[0].textContent.trim();
                                sold.txns = qtySpans[1].textContent.trim();
                            }
                        }
                    }

                    // Get PnL
                    let pnl = 'N/A';
                    const pnlEl = traderRow.querySelector('.custom-1e9y0rl');
                    if (pnlEl) {
                        pnl = pnlEl.textContent.trim();
                    }

                    traders.push({
                        rank,
                        wallet,
                        boughtUsd: bought.usd,
                        boughtQty: bought.qty,
                        boughtTxns: bought.txns,
                        soldUsd: sold.usd,
                        soldQty: sold.qty,
                        soldTxns: sold.txns,
                        pnl
                    });

                } catch (err) {
                    console.error('Error processing row:', err);
                }
            }

            console.log(`Successfully extracted ${traders.length} traders`);
            return traders;

        } catch (err) {
            console.error('Error during extraction:', err);
            return [];
        }
    }

    function displayTraders(traders, container) {
        container.innerHTML = '';
        if (!traders.length) {
            container.innerHTML = `
                <div style="text-align: center; padding: 20px; color: #666;">
                    <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="12" cy="12" r="10"></circle>
                        <line x1="12" y1="8" x2="12" y2="12"></line>
                        <line x1="12" y1="16" x2="12.01" y2="16"></line>
                    </svg>
                    <p style="margin-top: 10px;">No traders found</p>
                </div>`;
            return;
        }

        const copyAllBtn = document.createElement('button');
        copyAllBtn.textContent = 'Copy All Wallets';
        copyAllBtn.className = 'track-button copy-all';
        copyAllBtn.addEventListener('click', () => {
            const csv = traders.map(t => t.wallet).join('\n');
            navigator.clipboard.writeText(csv).then(() => {
                copyAllBtn.textContent = '✓ Copied All Wallets';
                setTimeout(() => {
                    copyAllBtn.textContent = 'Copy All Wallets';
                }, 2000);
            });
        });
        container.appendChild(copyAllBtn);

        traders.forEach((trader) => {
            const div = document.createElement('div');
            div.className = 'trader-result';

            const boughtUsd = formatCurrency(trader.boughtUsd);
            const soldUsd = formatCurrency(trader.soldUsd);
            const truncatedWallet = truncateWallet(trader.wallet);

            div.innerHTML = `
                <div class="wallet-info">
                    <span class="rank-badge">${trader.rank}</span>
                    <div class="wallet-address">
                        <span title="${trader.wallet}">${truncatedWallet}</span>
                    </div>
                    <div class="wallet-links">
                        <button class="wallet-button" title="View on Solscan"
                                onclick="window.open('https://solscan.io/account/${trader.wallet}', '_blank')">
                            <svg class="action-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
                                <polyline points="15 3 21 3 21 9"></polyline>
                                <line x1="10" y1="14" x2="21" y2="3"></line>
                            </svg>
                        </button>
                        <button class="wallet-button copy-wallet" data-wallet="${trader.wallet}" title="Copy wallet address">
                            <svg class="action-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                                <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                            </svg>
                        </button>
                    </div>
                </div>
                <div class="trading-stats">
                    <div class="stat-box">
                        <span class="stat-label">Bought</span>
                        <span class="stat-value bought-value">${boughtUsd}</span>
                        <span class="txn-count">
                            <svg class="trader-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M19 5h-7l-2-3H5C3.9 2 3 2.9 3 4v16c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zM5 4h5l2 3h7v1H5V4z"/>
                                <path d="M8 12h8M12 8v8"/>
                            </svg>
                            ${formatTransactions(trader.boughtTxns)} txns
                        </span>
                    </div>
                    <div class="stat-box">
                        <span class="stat-label">Sold</span>
                        <span class="stat-value sold-value">${soldUsd}</span>
                        <span class="txn-count">
                            <svg class="trader-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M19 5h-7l-2-3H5C3.9 2 3 2.9 3 4v16c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zM5 4h5l2 3h7v1H5V4z"/>
                                <path d="M8 12h8"/>
                            </svg>
                            ${formatTransactions(trader.soldTxns)} txns
                        </span>
                    </div>
                    <div class="stat-box">
                        <span class="stat-label">PnL</span>
                        <span class="stat-value ${trader.pnl.includes('-') ? 'pnl-negative' : 'pnl-positive'}">
                            ${trader.pnl}
                            ${trader.pnl.includes('-') ?
                                `<svg class="trader-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M12 20V4M6 14l6 6 6-6"/>
                                </svg>` :
                                `<svg class="trader-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M12 4v16M6 10l6-6 6 6"/>
                                </svg>`
                            }
                        </span>
                    </div>
                </div>
            `;

            container.appendChild(div);

            const copyBtn = div.querySelector('.copy-wallet');
            copyBtn.addEventListener('click', () => {
                const wallet = copyBtn.dataset.wallet;
                navigator.clipboard.writeText(wallet).then(() => {
                    copyBtn.innerHTML = `
                        <svg class="action-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M20 6L9 17l-5-5"></path>
                        </svg>
                    `;
                    setTimeout(() => {
                        copyBtn.innerHTML = `
                            <svg class="action-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                                <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                            </svg>
                        `;
                    }, 2000);
                });
            });
        });
    }

        let currentTraders = [];
    let filteredTraders = [];

    // Add this to your createUI function, right after the token-info-container
function createFilterSection() {
    const filterSection = document.createElement('div');
    filterSection.className = 'filter-section';
    filterSection.innerHTML = `
        <div class="filter-header">
            <div class="filter-title">
                <span>Trading Filters</span>
                <span class="filter-badge"></span>
            </div>
            <svg class="filter-toggle" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M18 15l-6-6-6 6"/>
            </svg>
        </div>
        <div class="filter-content">
            <div class="filter-grid">
                <div class="filter-group">
                    <label class="filter-label">Bought Amount (USD)</label>
                    <input type="number" class="filter-input" id="minBoughtFilter" placeholder="Min bought amount">
                </div>
                <div class="filter-group">
                    <label class="filter-label">Sold Amount (USD)</label>
                    <input type="number" class="filter-input" id="minSoldFilter" placeholder="Min sold amount">
                </div>
                <div class="filter-group">
                    <label class="filter-label">Buy Transactions</label>
                    <input type="number" class="filter-input" id="minBuyTxnsFilter" placeholder="Min buy transactions">
                </div>
                <div class="filter-group">
                    <label class="filter-label">Sell Transactions</label>
                    <input type="number" class="filter-input" id="minSellTxnsFilter" placeholder="Min sell transactions">
                </div>
            </div>
            <div class="filter-actions">
                <button class="filter-button apply-filters">Apply Filters</button>
                <button class="filter-button reset-filters">Reset</button>
            </div>
        </div>
        <div class="filter-status"></div>
    `;

    // Add toggle functionality
    const header = filterSection.querySelector('.filter-header');
    header.addEventListener('click', () => {
        filterSection.classList.toggle('collapsed');
    });

    return filterSection;
}

    // Add these filter utility functions
    function parseValue(value) {
        if (!value) return null;
        const numValue = parseFloat(value.replace(/[^0-9.-]/g, ''));
        return isNaN(numValue) ? null : numValue;
    }

function parseTransactionCount(value) {
    if (!value || value === 'N/A') return 0;

    // Clean the value and remove any non-numeric characters
    value = value.toString().replace(/[^\d.kK]/g, '').trim();

    // Handle 'k' suffix
    if (value.toLowerCase().includes('k')) {
        return Math.round(parseFloat(value) * 1000);
    }

    return Math.round(parseFloat(value)) || 0;
}

// Convert currency values for minimum thresholds
function convertToNumber(value) {
    if (typeof value === 'number') return value;
    if (!value || value === 'N/A') return 0;

    // Remove commas and $ symbol
    value = value.toString().replace(/[,$]/g, '').trim();

    // Handle negative values
    const isNegative = value.startsWith('-');
    if (isNegative) value = value.substring(1);

    // Match number and suffix
    const match = value.match(/([\d.]+)\s*([KMB])?/i);
    if (!match) return 0;

    let number = parseFloat(match[1]);
    const multiplier = match[2] ? {
        'K': 1000,
        'M': 1000000,
        'B': 1000000000
    }[match[2].toUpperCase()] : 1;

    number = number * multiplier;
    return isNegative ? -number : number;
}



function applyFilters(traders) {
    const minBought = ui.minBoughtFilter.value ? parseFloat(ui.minBoughtFilter.value) : null;
    const minSold = ui.minSoldFilter.value ? parseFloat(ui.minSoldFilter.value) : null;
    const exactBuyTxns = ui.minBuyTxnsFilter.value ? parseInt(ui.minBuyTxnsFilter.value) : null;
    const exactSellTxns = ui.minSellTxnsFilter.value ? parseInt(ui.minSellTxnsFilter.value) : null;

    console.log('Filter criteria:', {
        minBought,
        minSold,
        exactBuyTxns,
        exactSellTxns
    });

    return traders.filter(trader => {
        // Convert values
        const boughtAmount = convertToNumber(trader.boughtUsd);
        const soldAmount = convertToNumber(trader.soldUsd);
        const buyTxns = parseTransactionCount(trader.boughtTxns);
        const sellTxns = parseTransactionCount(trader.soldTxns);

        // Debug log
        console.log('Trader values:', {
            wallet: trader.wallet,
            boughtAmount,
            soldAmount,
            buyTxns,
            sellTxns
        });

        // Apply filters - minimum for amounts, exact for transactions
        const passesBought = minBought === null || boughtAmount >= minBought;
        const passesSold = minSold === null || soldAmount >= minSold;
        const matchesBuyTxns = exactBuyTxns === null || buyTxns === exactBuyTxns;
        const matchesSellTxns = exactSellTxns === null || sellTxns === exactSellTxns;

        // Debug log for matches
        console.log('Filter matches:', {
            wallet: trader.wallet,
            passesBought,
            passesSold,
            matchesBuyTxns,
            matchesSellTxns
        });

        // Return true only if passes all active filters
        return passesBought && passesSold && matchesBuyTxns && matchesSellTxns;
    });
}


    async function handleExtraction() {
        ui.trackButton.textContent = 'Loading...';
        ui.trackButton.disabled = true;

        try {
            const tabOpened = await ensureTopTradersTabOpen();
            if (!tabOpened) {
                console.log('[DexScreener Enhanced] Trying extraction anyway...');
            }

            await new Promise(resolve => setTimeout(resolve, 2000));

            currentTraders = await extractTopTraders();
            if (currentTraders.length === 0) {
                ui.tradersList.innerHTML = `
                    <div style="text-align: center; padding: 20px; color: #666;">
                        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="12" cy="12" r="10"></circle>
                            <line x1="12" y1="8" x2="12" y2="12"></line>
                            <line x1="12" y1="16" x2="12.01" y2="16"></line>
                        </svg>
                        <p style="margin-top: 10px;">No traders found. Please make sure you're on the Top Traders tab and try again.</p>
                    </div>
                `;
            } else {
                filteredTraders = applyFilters(currentTraders);
                displayTraders(filteredTraders, ui.tradersList);
                updateFilterStatus();
            }
        } catch (err) {
            console.error('Error during extraction:', err);
            ui.tradersList.innerHTML = `
                <div style="text-align: center; padding: 20px; color: #ff3d00;">
                    <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="12" cy="12" r="10"></circle>
                        <line x1="12" y1="8" x2="12" y2="12"></line>
                        <line x1="12" y1="16" x2="12.01" y2="16"></line>
                    </svg>
                    <p style="margin-top: 10px;">Error extracting traders. Please try again.</p>
                </div>
            `;
        } finally {
            ui.trackButton.textContent = 'Extract Top Traders';
            ui.trackButton.disabled = false;
        }
    }

    function setupFilterListeners() {
    // Apply filters on input change with debounce
    let timeout;
    const filterInputs = [
        ui.minBoughtFilter,
        ui.minSoldFilter,
        ui.minBuyTxnsFilter,
        ui.minSellTxnsFilter
    ];

    filterInputs.forEach(input => {
        input.addEventListener('input', () => {
            clearTimeout(timeout);
            timeout = setTimeout(() => {
                if (currentTraders.length > 0) {
                    filteredTraders = applyFilters(currentTraders);
                    displayTraders(filteredTraders, ui.tradersList);
                    updateFilterStatus();
                }
            }, 300);
        });

        // Enter key support
        input.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                clearTimeout(timeout);
                if (currentTraders.length > 0) {
                    filteredTraders = applyFilters(currentTraders);
                    displayTraders(filteredTraders, ui.tradersList);
                    updateFilterStatus();
                }
            }
        });
    });

    // Reset button
    ui.resetFiltersBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        resetFilters();
    });
}

function updateFilterStatus() {
    const totalTraders = currentTraders.length;
    const filteredCount = filteredTraders.length;
    const activeFilters = [
        ui.minBoughtFilter.value,
        ui.minSoldFilter.value,
        ui.minBuyTxnsFilter.value,
        ui.minSellTxnsFilter.value
    ].filter(Boolean).length;

    let statusText = `Showing ${filteredCount} of ${totalTraders} traders`;
    if (activeFilters > 0) {
        statusText += ` (${activeFilters} filter${activeFilters > 1 ? 's' : ''} active)`;
    }

    ui.filterStatus.textContent = statusText;
}

function createUI() {
    const container = document.createElement('div');
    container.className = 'dex-traders-tracker';
    container.innerHTML = `
        <div class="bubble-icon">🔍</div>
        <div class="traders-header">
            <strong>DexScreener Traders</strong>
            <span class="minimize-button">
                <span class="minimize-icon">—</span>
            </span>
        </div>
        <div class="token-info-container"></div>
        <div class="filter-section">
            <div class="filter-header">
                <div class="filter-title">
                    <span>Trading Filters</span>
                    <span class="filter-badge"></span>
                </div>
                <svg class="filter-toggle" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M18 15l-6-6-6 6"/>
                </svg>
            </div>
            <div class="filter-content">
                <div class="filter-grid">
                    <div class="filter-group">
                        <label class="filter-label">Bought Amount (USD)</label>
                        <input type="number" class="filter-input" id="minBoughtFilter" placeholder="Min bought amount">
                    </div>
                    <div class="filter-group">
                        <label class="filter-label">Sold Amount (USD)</label>
                        <input type="number" class="filter-input" id="minSoldFilter" placeholder="Min sold amount">
                    </div>
                    <div class="filter-group">
                        <label class="filter-label">Buy Transactions</label>
                        <input type="number" class="filter-input" id="minBuyTxnsFilter" placeholder="Min buy transactions">
                    </div>
                    <div class="filter-group">
                        <label class="filter-label">Sell Transactions</label>
                        <input type="number" class="filter-input" id="minSellTxnsFilter" placeholder="Min sell transactions">
                    </div>
                </div>
                <div class="filter-actions">
                    <button class="filter-button apply-filters">Apply Filters</button>
                    <button class="filter-button reset-filters">Reset</button>
                </div>
            </div>
            <div class="filter-status"></div>
        </div>
        <button class="track-button">Extract Top Traders</button>
        <div class="traders-list"></div>
    `;

    document.body.appendChild(container);

    // Initialize UI object with all elements
    ui = {
        container,
        bubbleIcon: container.querySelector('.bubble-icon'),
        minimizeButton: container.querySelector('.minimize-button'),
        tokenInfoContainer: container.querySelector('.token-info-container'),
        trackButton: container.querySelector('.track-button'),
        tradersList: container.querySelector('.traders-list'),
        filterSection: container.querySelector('.filter-section'),
        filterHeader: container.querySelector('.filter-header'),
        filterContent: container.querySelector('.filter-content'),
        minBoughtFilter: container.querySelector('#minBoughtFilter'),
        minSoldFilter: container.querySelector('#minSoldFilter'),
        minBuyTxnsFilter: container.querySelector('#minBuyTxnsFilter'),
        minSellTxnsFilter: container.querySelector('#minSellTxnsFilter'),
        filterStatus: container.querySelector('.filter-status'),
        applyFiltersBtn: container.querySelector('.apply-filters'),
        resetFiltersBtn: container.querySelector('.reset-filters')
    };

    // Initialize page metadata
    const metadata = extractPageMetadata();
    displayMetadata(metadata, ui.tokenInfoContainer);

    // Set up filter toggle functionality
    ui.filterHeader.addEventListener('click', (e) => {
        if (!e.target.closest('.filter-button')) {
            ui.filterSection.classList.toggle('collapsed');
        }
    });

    // Set up filter actions
    ui.applyFiltersBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        if (currentTraders.length > 0) {
            filteredTraders = applyFilters(currentTraders);
            displayTraders(filteredTraders, ui.tradersList);
            updateFilterStatus();
            ui.filterSection.classList.add('collapsed');
        }
    });

    ui.resetFiltersBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        ui.minBoughtFilter.value = '';
        ui.minSoldFilter.value = '';
        ui.minBuyTxnsFilter.value = '';
        ui.minSellTxnsFilter.value = '';
        if (currentTraders.length > 0) {
            filteredTraders = [...currentTraders];
            displayTraders(filteredTraders, ui.tradersList);
            updateFilterStatus();
        }
    });

    // Enter key support for filters
    const filterInputs = [
        ui.minBoughtFilter,
        ui.minSoldFilter,
        ui.minBuyTxnsFilter,
        ui.minSellTxnsFilter
    ];

    filterInputs.forEach(input => {
        input.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                ui.applyFiltersBtn.click();
            }
        });
    });

    // Set up extraction functionality
    ui.trackButton.addEventListener('click', async () => {
        ui.trackButton.textContent = 'Loading...';
        ui.trackButton.disabled = true;

        try {
            const tabOpened = await ensureTopTradersTabOpen();
            if (!tabOpened) {
                console.log('[DexScreener Enhanced] Trying extraction anyway...');
            }

            await new Promise(resolve => setTimeout(resolve, 2000));

            currentTraders = await extractTopTraders();
            if (currentTraders.length === 0) {
                ui.tradersList.innerHTML = `
                    <div style="text-align: center; padding: 20px; color: #666;">
                        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="12" cy="12" r="10"></circle>
                            <line x1="12" y1="8" x2="12" y2="12"></line>
                            <line x1="12" y1="16" x2="12.01" y2="16"></line>
                        </svg>
                        <p style="margin-top: 10px;">No traders found. Please make sure you're on the Top Traders tab and try again.</p>
                    </div>
                `;
                ui.filterSection.classList.add('collapsed');
            } else {
                filteredTraders = applyFilters(currentTraders);
                displayTraders(filteredTraders, ui.tradersList);
                updateFilterStatus();
                ui.filterSection.classList.remove('collapsed');
            }
        } catch (err) {
            console.error('Error during extraction:', err);
            ui.tradersList.innerHTML = `
                <div style="text-align: center; padding: 20px; color: #ff3d00;">
                    <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="12" cy="12" r="10"></circle>
                        <line x1="12" y1="8" x2="12" y2="12"></line>
                        <line x1="12" y1="16" x2="12.01" y2="16"></line>
                    </svg>
                    <p style="margin-top: 10px;">Error extracting traders. Please try again.</p>
                </div>
            `;
            ui.filterSection.classList.add('collapsed');
        } finally {
            ui.trackButton.textContent = 'Extract Top Traders';
            ui.trackButton.disabled = false;
        }
    });

    // Set up minimize/maximize functionality
    ui.minimizeButton.addEventListener('click', () => {
        ui.container.classList.add('minimized');
    });

    ui.bubbleIcon.addEventListener('click', (e) => {
        e.stopPropagation();
        ui.container.classList.remove('minimized');
    });

    // Set up URL change watcher
    watchUrlChanges(1500);

    return ui;
}

    function init() {
        console.log('[DexScreener Enhanced] Initializing...');
        if (document.querySelector('.dex-traders-tracker')) {
            console.log('[DexScreener Enhanced] Already initialized');
            return;
        }
        createUI();
        console.log('[DexScreener Enhanced] Initialized successfully');
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();